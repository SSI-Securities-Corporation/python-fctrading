ConsumerID = ""
ConsumerSecret = ""
PrivateKey = ""
Url = "https://fc-tradeapi.ssi.com.vn/"
StreamURL = "https://fc-tradehub.ssi.com.vn/"
TwoFAType = 0 # 0-PIN, 1-OTP
NotifyId = '-1'
