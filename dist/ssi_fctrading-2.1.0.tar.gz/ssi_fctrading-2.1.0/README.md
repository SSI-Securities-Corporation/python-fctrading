
# Run Example

- Install ssi-fctrading client: `pip install dist/ssi_fctrading-2.1.0.tar.gz`
- Install requirement: `pip install -r examples/requirements.txt`
- Config your key and PIN in file `examples/fc_config.py`
- Run `example_api.bat` to start example and open browser at [Swagger](http://127.0.0.1:8000/docs) to test
- Run `example_stream.bat` to start streaming